package ejemplos.patronDAO.modelo;

import java.time.LocalDate;
import java.util.GregorianCalendar;

public abstract class Persona {

    protected String dni;
    protected String nombre;
    protected String apellidos;
    protected LocalDate fechaNacim;


    public Persona(String dni, String nombre, String apellidos, LocalDate fechaNacim) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.fechaNacim = fechaNacim;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public abstract void mostrar ();

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public LocalDate getFechaNacim() {
        return fechaNacim;
    }

    public void setFechaNacim(LocalDate fechaNacim) {
        this.fechaNacim = fechaNacim;
    }
}
