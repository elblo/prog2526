package ejemplos.patronDAO.modelo;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.GregorianCalendar;

public class Profesor extends Persona {

    private String materia;
    private double salario;

    public Profesor(String dni, String nombre, String apellidos, LocalDate fechaNacim, String materia, double salario) {
        super(dni, nombre, apellidos, fechaNacim);
        this.materia = materia;
        this.salario = salario;
    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public void mostrar () {
        System.out.printf ("Nombre: %s\n", this.nombre);
        System.out.printf ("Apellidos: %s\n", this.apellidos);
        System.out.printf ("Fecha de nacimiento: %s\n", fechaNacim.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        System.out.printf ("Especialidad: %s\n", this.materia);
        System.out.printf ("Salario: %7.2f euros\n", this.salario);
    }

}

