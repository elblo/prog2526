package ejemplos.patronDAO;

import ejemplos.patronDAO.DAO.DAOManager;
import ejemplos.patronDAO.DAO.DaoAlumnoSQL;
import ejemplos.patronDAO.DAO.DaoProfesor;
import ejemplos.patronDAO.DAO.DaoProfesorSQL;
import ejemplos.patronDAO.modelo.Alumno;
import ejemplos.patronDAO.modelo.Profesor;
import org.w3c.dom.ls.LSOutput;

import javax.crypto.spec.PSource;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class main {

    public static void main(String[] args) {

        var s = new Scanner(System.in);

        // Crear DAO Manager
        DAOManager dao = DAOManager.getSinglentonInstance();
        DAOManager dao2 = DAOManager.getSinglentonInstance();
        if (dao2 == null) System.out.println("El singlenton funciona");

        // Abrir conexión con la BD
        try{
            dao.open();
            System.out.println("Conexión establecida");
        }catch (Exception e){
            System.out.println("Error de conexión en la BBDD");
        }

        // Crear los DAOs de Alumno y Profesor
        DaoAlumnoSQL daoAlumnoSQL = new DaoAlumnoSQL();
        DaoProfesorSQL daoProfesorSQL = new DaoProfesorSQL();

        // SELECT - Leer 1 alumno
        Alumno a2 = daoAlumnoSQL.read("77322947Y", dao);
        if (a2 == null) System.out.println("Alumno con dni 77322947Y no encontrado");
        else System.out.println("Alumno con dni 77322947Y encontrado");

        // INSERT
        LocalDate fechaN = LocalDate.of(2005, 11, 23);
        Alumno alumno = new Alumno("12345678L", "Jose", "García", fechaN, "1DAW", 8.5f);
        alumno.mostrar();
        if (daoAlumnoSQL.insert(alumno, dao)) System.out.println("Grabación correcta");
        else System.out.println("Ya existía el alumno");
        System.out.println();

        // UPDATE
        LocalDate fecha2 = LocalDate.now();
        Alumno alumno2 = new Alumno("12345679Z", "Josefa MODIFICADA", "García", fecha2, "1DAW", 9.5f);
        if (daoAlumnoSQL.update(alumno2, dao)) System.out.println("Grabación correcta");
        else System.out.println("Ya existía el alumno");
        System.out.println();

        // DELETE
        Profesor profesor = new Profesor("77322948P", "Jose", "Lopez Caro", fechaN, "Sistemas", 1600);
        if (daoProfesorSQL.delete(profesor, dao)) System.out.println("Grabación correcta");
        else System.out.println("Ya existía el profesor");
        System.out.println();

        // SELECT - Devolver todos los alumnos de la BD
        ArrayList<Alumno> todosAlumnos = daoAlumnoSQL.readAll(dao);
        for(Alumno a : todosAlumnos) a.mostrar();
        System.out.println();

        // SELECT - Devolver todos los profesores con apellidos "Lopez Caro"
        ArrayList<Profesor> profesoresApellido = daoProfesorSQL.readProfesoresByApellidos("Lopez Caro", dao);
        for(Profesor p : profesoresApellido) p.mostrar();

        // Cerrar conexión con la BD
        try {
            dao.close();
            System.out.println("Conexión con la BD cerrada");
        } catch (Exception e) {
            System.out.println("Error al cerrar la conexión con la BD");
            e.printStackTrace();
        }
    }
}
