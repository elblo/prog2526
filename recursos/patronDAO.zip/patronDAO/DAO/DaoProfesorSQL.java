package ejemplos.patronDAO.DAO;
import ejemplos.patronDAO.modelo.Profesor;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

// DAO Profesor
public class DaoProfesorSQL implements DaoProfesor {

    @Override
    public boolean insert(Profesor profesor, DAOManager dao) {
        String sentencia = "INSERT INTO profesores VALUES ('"
                + profesor.getDni() + "','"
                + profesor.getNombre() + "','"
                + profesor.getApellidos()  + "','"
                + profesor.getFechaNacim().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + "','"
                + profesor.getMateria() + "',"
                + profesor.getSalario()+ ");";
        System.out.println("sentencia = " + sentencia);
        try (Statement stmt = dao.getConn().createStatement()) {
            // enviar el commando insert
            stmt.executeUpdate(sentencia);
            return true;
        } catch (SQLException ex) {
            return false;
        }
    }

    @Override
    public boolean update(Profesor profesor, DAOManager dao) {
        String sentencia = "UPDATE profesores SET nombre = '"
                + profesor.getNombre() + "', apellidos = '"
                + profesor.getApellidos() + "', fecha_nac = '"
                + profesor.getFechaNacim().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + "', materia = '"
                + profesor.getMateria() + "', salario = "
                + profesor.getSalario() +
                " WHERE dni = '" + profesor.getDni() + "';";
        System.out.println("sentencia = " + sentencia);
        try (Statement stmt = dao.getConn().createStatement()) {
            // enviar el commando insert
            stmt.executeUpdate(sentencia);
            return true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean delete(Profesor profesor, DAOManager dao) {
        String sentencia = "delete from profesores where dni = '" + profesor.getDni() + "';";
        System.out.println("sentencia = " + sentencia);
        try (Statement stmt = dao.getConn().createStatement()) {
            // enviar el commando delete
            stmt.executeUpdate(sentencia);
            return true;
        } catch (SQLException ex) {
            return false;
        }
    }

    @Override
    public Profesor read(String dni, DAOManager dao) {
        Profesor profesor = null;
        String sentencia = "SELECT * FROM profesores WHERE dni = ?";
        try {
            PreparedStatement ps = dao.getConn().prepareStatement(sentencia);
            ps.setString(1, dni);
            System.out.println("sentencia = " + sentencia);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    LocalDate cal2 = LocalDate.parse(rs.getString("fecha_nac"), DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                    // obtener cada una de la columnas y mapearlas a la clase Alumno
                    profesor = new Profesor(dni,
                            rs.getString("nombre"),
                            rs.getString("apellidos"),
                            cal2,
                            rs.getString("materia"),
                            rs.getDouble("salario"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return profesor;
    }

    // Método que lee todos los profesores con los apellidos indicados y los devuelve en un ArrayList
    public ArrayList<Profesor> readProfesoresByApellidos(String apellidos, DAOManager dao) {
        ArrayList<Profesor> profesores = new ArrayList<>();
        String sentencia = "SELECT * FROM profesores WHERE apellidos = ?";
        try {
            PreparedStatement ps = dao.getConn().prepareStatement(sentencia);
            ps.setString(1, apellidos);
            System.out.println("sentencia = " + sentencia);
            try (ResultSet rs = ps.executeQuery()) {
                while(rs.next()) {
                    LocalDate cal2 = LocalDate.parse(rs.getString("fecha_nac"), DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                    // Añadir el profesor al ArrayList
                    profesores.add(new Profesor(rs.getString("dni"),
                            rs.getString("nombre"),
                            rs.getString("apellidos"),
                            cal2,
                            rs.getString("materia"),
                            rs.getDouble("salario"))
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return profesores;
    }
}

