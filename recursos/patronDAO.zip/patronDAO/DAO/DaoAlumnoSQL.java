package ejemplos.patronDAO.DAO;

import ejemplos.patronDAO.modelo.Alumno;

import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

// DAO Alumno
public class DaoAlumnoSQL implements DaoAlumno {

    // Ejemplo de refactorización
    // TODO hacer igual en DaoProfesorSQL
    // Método para lanzar sentencias INSERT, UPDATE y DELETE
    public boolean ejecutaSentencia(String sentencia, DAOManager dao){
        System.out.println("sentencia = " + sentencia);
        try {
            Statement stmt = dao.getConn().createStatement();
            stmt.executeUpdate(sentencia);
            return true;
        } catch (SQLException ex) {
            return false;
        }
    }

    @Override
    public boolean insert(Alumno alumno, DAOManager dao) {
        String sentencia = "INSERT INTO alumnos VALUES ('"
                + alumno.getDni() + "','"
                + alumno.getNombre() + "','"
                + alumno.getApellidos() + "','"
                + alumno.getFechaNacim().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + "','"
                + alumno.getGrupo() + "',"
                + alumno.getNotaMedia() + ");";

        boolean resultado = ejecutaSentencia(sentencia, dao);
        return resultado;
    }

    @Override
    public boolean update(Alumno alumno, DAOManager dao) {
        String sentencia = "UPDATE alumnos SET nombre = '"
                + alumno.getNombre() + "', apellidos = '"
                + alumno.getApellidos() + "', fecha_nac = '"
                + alumno.getFechaNacim().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + "', grupo = '"
                + alumno.getGrupo() + "', nota_media = "
                + alumno.getNotaMedia() +
                " WHERE dni = '" + alumno.getDni() + "';";

        boolean resultado = ejecutaSentencia(sentencia, dao);
        return resultado;
    }

    @Override
    public boolean delete(Alumno alumno, DAOManager dao) {
        String sentencia = "DELETE FROM alumnos WHERE dni = '" + alumno.getDni() + "';";

        boolean resultado = ejecutaSentencia(sentencia, dao);
        return resultado;
    }

    @Override
    public Alumno read(String dni, DAOManager dao) {
        Alumno alumno = null;
        String sentencia = "SELECT * FROM alumnos WHERE dni = ?";
        try {
            PreparedStatement ps = dao.getConn().prepareStatement(sentencia);
            ps.setString(1, dni);
            System.out.println("sentencia = " + sentencia);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    LocalDate cal2 = LocalDate.parse(rs.getString("fecha_nac"), DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                    // obtener cada una de la columnas y mapearlas a la clase Alumno
                    alumno = new Alumno(dni,
                            rs.getString("nombre"),
                            rs.getString("apellidos"),
                            cal2,
                            rs.getString("grupo"),
                            rs.getDouble("nota_media"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return alumno;
    }

    // Método que lee todos los alumnos y los devuelve en un ArrayList
    public ArrayList<Alumno> readAll(DAOManager dao) {
        ArrayList<Alumno> alumnos = new ArrayList<>();
        String sentencia = "SELECT * FROM alumnos";
        try {
            PreparedStatement ps = dao.getConn().prepareStatement(sentencia);
            //ps.setString(1, dni);
            System.out.println("sentencia = " + sentencia);
            try (ResultSet rs = ps.executeQuery()) {
                while(rs.next()) {
                    //Calendar cal = Calendar.getInstance();
                    LocalDate cal2 = LocalDate.parse(rs.getString("fecha_nac"), DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                    // Añadir el alumno al ArrayList
                    alumnos.add(new Alumno(rs.getString("dni"),
                            rs.getString("nombre"),
                            rs.getString("apellidos"),
                            cal2,
                            rs.getString("grupo"),
                            rs.getDouble("nota_media")));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return alumnos;
    }
}
